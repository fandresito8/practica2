#ifndef COMPORTAMIENTOINGENIERO_H
#define COMPORTAMIENTOINGENIERO_H

#include <chrono>
#include <list>
#include <map>
#include <set>
#include <thread>
#include <time.h>
#include <climits>

#include "comportamientos/comportamiento.hpp"

struct EstadoI {
  ubicacion site;
  bool zapatillas;

  bool operator==(const EstadoI &st) const {
    return site == st.site and zapatillas == st.zapatillas;
  }
};

// Nodo para el algoritmo de búsqueda
struct NodoI {
  EstadoI estado;
  list<Action> secuencia;

  bool operator==(const NodoI &node) const {
    return estado == node.estado;
  }

  bool operator<(const NodoI &node) const{
    if (estado.site.f < node.estado.site.f) return true;
    else if (estado.site.f == node.estado.site.f and estado.site.c < node.estado.site.c) return true;
    else if (estado.site.f == node.estado.site.f and estado.site.c == node.estado.site.c and
             estado.site.brujula < node.estado.site.brujula) return true;
    else if (estado.site.f == node.estado.site.f and estado.site.c == node.estado.site.c and
             estado.site.brujula == node.estado.site.brujula and
             estado.zapatillas < node.estado.zapatillas) return true;
    else return false;
  }
};

struct EstadoTuberia {
    int f;
    int c;
    int op; // La operación aplicada: -1 (DIG), 0 (Nada), 1 (RAISE)

    bool operator<(const EstadoTuberia &o) const {
        if (f != o.f) return f < o.f;
        if (c != o.c) return c < o.c;
        return op < o.op;
    }
};

struct NodoBFS4 {
    EstadoTuberia estado;
    list<Paso> camino;
    int energia_gastada;
    int eco_gastado;
};

class ComportamientoIngeniero : public Comportamiento {
public:
  // =========================================================================
  // CONSTRUCTORES
  // =========================================================================
  
  /**
   * @brief Constructor para niveles 0, 1 y 6 (sin mapa completo)
   * @param size Tamaño del mapa (si es 0, se inicializa más tarde)
   */
  ComportamientoIngeniero(unsigned int size = 0) : Comportamiento(size) {
    last_action = IDLE;
    tiene_zapatillas = false;
    pasos_desde_ultima_visita = 0;
    giros_consecutivos = 0;
    pasos_evasion = 0;
    gira_izq = true;
  }

  /**
   * @brief Constructor para niveles 2, 3, 4 y 5 (con mapa completo conocido)
   * @param mapaR Mapa de terreno conocido
   * @param mapaC Mapa de cotas conocido
   */
  ComportamientoIngeniero(std::vector<std::vector<unsigned char>> mapaR, 
                         std::vector<std::vector<unsigned char>> mapaC): 
                         Comportamiento(mapaR, mapaC) {
    hayPlan = false;
    tiene_zapatillas = false;
    comprobando_obstaculiza = true;
    pasos_evasion = 0;

    hayPlanPasosTuberias = false;

    estadoAgente = 0;
    tramo_actual = 0;
    cota_ajustada = false;
    he_llamado_tecnico = false;
  }

  ComportamientoIngeniero(const ComportamientoIngeniero &comport)
      : Comportamiento(comport) {}
  ~ComportamientoIngeniero() {}

  /**
   * @brief Bucle principal de decisión del agente.
   * Estudia los sensores y decide la siguiente acción.
   * 
   * EJEMPLO DE USO:
   * Action accion = think(sensores);
   * return accion; // El motor ejecutará esta acción
   */
  Action think(Sensores sensores);

  ComportamientoIngeniero *clone() {
    return new ComportamientoIngeniero(*this);
  }

  // =========================================================================
  // ÁREA DE IMPLEMENTACIÓN DEL ESTUDIANTE
  // =========================================================================

  // Funciones específicas para cada nivel (para ser implementadas por el alumno)
  
  /**
   * @brief Implementación del Nivel 0.
   * @param sensores Datos actuales de los sensores del agente.
   * @return Acción a realizar.
   */
  Action ComportamientoIngenieroNivel_0(Sensores sensores);
  
  /**
   * @brief Implementación del Nivel 1.
   * @param sensores Datos actuales de los sensores del agente.
   * @return Acción a realizar.
   */
  Action ComportamientoIngenieroNivel_1(Sensores sensores);

  /**
   * @brief Implementación del Nivel 2.
   * @param sensores Datos actuales de los sensores del agente.
   * @return Acción a realizar.
   */ 
  Action ComportamientoIngenieroNivel_2(Sensores sensores);
  
  /**
   * @brief Implementación del Nivel 3.
   * @param sensores Datos actuales de los sensores del agente.
   * @return Acción a realizar.
   */
  Action ComportamientoIngenieroNivel_3(Sensores sensores);
  
  /**
   * @brief Implementación del Nivel 4.
   * @param sensores Datos actuales de los sensores del agente.
   * @return Acción a realizar.
   */
  Action ComportamientoIngenieroNivel_4(Sensores sensores);
  
  /**
   * @brief Implementación del Nivel 5.
   * @param sensores Datos actuales de los sensores del agente.
   * @return Acción a realizar.
   */
  Action ComportamientoIngenieroNivel_5(Sensores sensores);
  
  /**
   * @brief Implementación del Nivel 6.
   * @param sensores Datos actuales de los sensores del agente.
   * @return Acción a realizar.
   */
  Action ComportamientoIngenieroNivel_6(Sensores sensores);

protected:
  // =========================================================================
  // FUNCIONES PROPORCIONADAS
  // =========================================================================

  /**
   * @brief Actualiza la información del mapa interno basándose en los sensores.
   * IMPORTANTE: Esta función ya está implementada. Actualiza mapaResultado y mapaCotas
   * con la información de los 16 sensores (casilla actual + 15 casillas alrededor).
   */
  void ActualizarMapa(Sensores sensores);

  /**
   * @brief Comprueba si una casilla es transitable.
   * @param f Fila de la casilla.
   * @param c Columna de la casilla.
   * @param tieneZapatillas Indica si el agente posee zapatillas.
   * @return true si la casilla es transitable (no es muro ni precipicio).
   */
  bool EsCasillaTransitableLevel0(int f, int c, bool tieneZapatillas);

  /**
   * @brief Comprueba si la casilla de delante es accesible por diferencia de altura.
   * REGLAS: Desnivel máximo 1 sin zapatillas, 2 con zapatillas.
   * @param actual Estado actual del agente (fila, columna, orientacion).
   * @return true si el desnivel con la casilla de delante es admisible.
   */
  bool EsAccesiblePorAltura(const ubicacion &actual, bool zap);

  /**
   * @brief Devuelve la posición (fila, columna) de la casilla que hay delante del agente.
   * @param actual Estado actual del agente (fila, columna, orientacion).
   * @return Estado con la fila y columna de la casilla de enfrente.
   */
  ubicacion Delante(const ubicacion &actual) const;

  /**
   * @brief Devuelve la posición (fila, columna) de la casilla diagonal izquierda respecto al agente.
   * @param actual Estado actual del agente (fila, columna, orientacion).
   * @return Estado con la fila y columna de la casilla diagonal izquierda.
   */
  ubicacion Izquierda(const ubicacion &actual) const;

  /**
   * @brief Devuelve la posición (fila, columna) de la casilla diagonal derecha respecto al agente.
   * @param actual Estado actual del agente (fila, columna, orientacion).
   * @return Estado con la fila y columna de la casilla diagonal derecha.
   */
  ubicacion Derecha(const ubicacion &actual) const;

  EstadoI NextCasillaIngeniero(const EstadoI &st);

  bool CasillaAccesibleIngeniero(const EstadoI &st,
                                 const vector<vector<unsigned char>> &terreno,
                                 const vector<vector<unsigned char>> &altura);

  bool IntermediaAccesible(const EstadoI &st,
                           const vector<vector<unsigned char>> &terreno,
                           const vector<vector<unsigned char>> &altura);

  EstadoI applyI(Action accion, const EstadoI & st,
                 const vector<vector<unsigned char>> &terreno,
                 const vector<vector<unsigned char>> &altura);

  void PintaPlan(const list<Action> &plan, bool zap);

  list<Action> B_Anchura(const EstadoI &inicio, const EstadoI &final,
                         const vector<vector<unsigned char>> &terreno,
                         const vector<vector<unsigned char>> &altura);

  bool es_camino(unsigned char c) const;

  list<Paso> PlanificarTuberias(int belF, int belC, int max_energia, int max_eco);

  int CosteInstallEnergia(unsigned char t);

  int CosteInstallEco(unsigned char t);

  int CosteRaise(unsigned char t);

  int CosteDig(unsigned char t);

  /**
 * @brief Imprime por consola la secuencia de acciones de un plan para un agente.
 * @param plan  Lista de acciones del plan.
 */
  void PintaPlan(const list<Action> &plan);


/**
 * @brief Imprime las coordenadas y operaciones de un plan de tubería.
 * @param plan  Lista de pasos (fila, columna, operación).
 */
  void PintaPlan(const list<Paso> &plan);


  /**
 * @brief Convierte un plan de acciones en una lista de casillas para
 *        su visualización en el mapa gráfico.
 * @param st    Estado de partida.
 * @param plan  Lista de acciones del plan.
 */
  void VisualizaPlan(const ubicacion &st, const list<Action> &plan);

  /**
 * @brief Convierte un plan de tubería en la lista de casillas usada
 *        por el sistema de visualización.
 * @param st    Estado de partida (no utilizado directamente).
 * @param plan  Lista de pasos del plan de tubería.
 */
  void VisualizaRedTuberias(const list<Paso> &plan);



private:
  // =========================================================================
  // VARIABLES DE ESTADO (PUEDEN SER EXTENDIDAS POR EL ALUMNO)
  // =========================================================================
  // Reactivos (Niveles 0 y 1)
  Action last_action;
  bool tiene_zapatillas;
  vector<vector<int>> mapa_visitas;
  int pasos_desde_ultima_visita;
  int giros_consecutivos;
  int pasos_evasion;
  bool gira_izq;

  // Deliberativos (Niveles 2 y 3)
  list<Action> plan;
  bool hayPlan;
  bool comprobando_obstaculiza;

  // Nivel 4
  list<Paso> planPasosTuberias;
  bool hayPlanPasosTuberias;

  //Nivel 5
  int estadoAgente; // 0:PLANIFICAR, 1:DESPLAZAR, 2:COTA, 3:ESPERAR, 4:INSTALAR, 5:FIN
  int tramo_actual;
  bool cota_ajustada;
  bool he_llamado_tecnico;
};

#endif
